package org.example;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.mockito.Mockito.*;

class FileParserTest {
    @Test
    void testFillDictionary() throws IOException {
        FileParser mockFileParser = mock(FileParser.class);
       // when(mockFileParser.fillDictionary("Larousse")).thenReturn(2);
        //verify(mockFileParser).fillDictionary("Larousse");
    }
}