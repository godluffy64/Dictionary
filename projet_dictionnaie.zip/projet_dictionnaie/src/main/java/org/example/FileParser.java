package org.example;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class FileParser
{
    private BufferedReader br;
    public FileParser(BufferedReader br)
    {
        this.br = br;
    }
    public void fillDictionary(String id) throws IOException {
        String line;
        String list[];
        ArrayList <String> traduction = new ArrayList<>();
        line = br.readLine();
        Dictionary dictionary = new Dictionary(line);
        try
        {
            while (line != null) {
                line = br.readLine();
                list = line.split(";");
                traduction.add(list[1]);
                for (String word : list)
                {
                    dictionary.addTranslation(word, traduction);
                }
                traduction.remove(0);
            }
            br.close();
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Fichier non trouvé");
        }
    }
}
