package org.example;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class FileParser
{
    private Scanner scanner;
    public Dictionary dictionary;
    public FileParser(Scanner sc)
    {
        this.scanner = sc;
    }

    public void fillDictionary(String id)
    {
        String line;
        String list[];

        boolean first_word = true;
        dictionary = new Dictionary(scanner.nextLine());

        /*line = scanner.nextLine();
        list = line.split(";");
        ArrayList <String> traduction = new ArrayList<>();
        traduction.add(list[0]);
        for (String word : list)
        {
            if (!first_word)  dictionary.addTranslation(word, traduction);
            else first_word = false;
        }
        scanner.close();*/
        ArrayList <String> traduction = new ArrayList<>();
        for(int i = 0; i < 3; i++)
        {
            line = scanner.nextLine();
            list = line.split(";");

            traduction.add(list[0]);
            for (String word : list)
            {
                if (!first_word)  dictionary.addTranslation(word, traduction);
                else first_word = false;
            }
            traduction.remove(0);
            first_word = true;
        }
        scanner.close();
    }
}
