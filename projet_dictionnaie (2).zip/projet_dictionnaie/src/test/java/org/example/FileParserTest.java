package org.example;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FileParserTest {
    FileParser fileParserUnderTest;

    @Mock
    Scanner mockScanner;


    @BeforeEach
    public void setup() throws IOException {
        MockitoAnnotations.initMocks(this);
        fileParserUnderTest = new FileParser(mockScanner);
        Mockito.when(mockScanner.nextLine())
                .thenReturn("Larousse")
                .thenReturn("Bonjour;Hello")
                .thenReturn("Salut;Hello");



    }
    @Test
    void testFillDictionary() throws IOException {

        fileParserUnderTest.fillDictionary("1234");
        ArrayList <String> traduction = new ArrayList<>();
        traduction.add("Hello");

        assertEquals("Larousse", fileParserUnderTest.dictionary.getName());
        //verify(mockScanner, times(2)).nextLine();
        assertFalse(fileParserUnderTest.dictionary.isEmpty());
        assertEquals(traduction, fileParserUnderTest.dictionary.getMultipleTranslations("Bonjour"));
        assertEquals(traduction, fileParserUnderTest.dictionary.getMultipleTranslations("Salut"));
    }
}